-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Počítač: localhost
-- Vytvořeno: Pon 29. led 2018, 10:06
-- Verze serveru: 10.0.31-MariaDB
-- Verze PHP: 5.5.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `civrny`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `zboziBarf`
--

CREATE TABLE IF NOT EXISTS `zboziBarf` (
  `ID` int(11) NOT NULL,
  `vyrobek` text NOT NULL,
  `img_path` text NOT NULL,
  `skladem` int(11) NOT NULL,
  `koupeno` int(11) NOT NULL,
  `cena` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Vypisuji data pro tabulku `zboziBarf`
--

INSERT INTO `zboziBarf` (`ID`, `vyrobek`, `img_path`, `skladem`, `koupeno`, `cena`) VALUES
(1, 'Hovězí játra', 'img/HJ.jpg', 6, 12, 29),
(2, 'Hovězí Kostky', 'img/HK.jpg', 2, 8, 89),
(3, 'Makrela v celku', 'img/MvC.jpg', 1, 15, 89),
(4, 'Hovězí svalovina s droby', 'img/HSsD.jpg', 10, 3, 27),
(5, 'Koňská svalovina kusová', 'img/VZ.jpg', 12, 3, 121),
(6, 'Selečí sekané', 'img/SS.jpg', 8, 3, 69);

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `zboziBarf`
--
ALTER TABLE `zboziBarf`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `zboziBarf`
--
ALTER TABLE `zboziBarf`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
